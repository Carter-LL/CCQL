package com.github.gamechampcrafted.CCQL;

import java.util.Properties;

public class CQL_PROPERTY {
    public CQL_PROPERTIES[] props;

    public CQL_PROPERTY(CQL_PROPERTIES...props) {
        this.props = props;
    }
}
