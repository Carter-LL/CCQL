package com.github.gamechampcrafted.CCQL;

public enum CQL_PROPERTIES {
    AUTOCLOSE,
    AUTOEXECUTE,
}
