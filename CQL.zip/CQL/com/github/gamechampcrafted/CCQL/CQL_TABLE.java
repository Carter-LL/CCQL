package com.github.gamechampcrafted.CCQL;

public class CQL_TABLE {
    public Object TABLE;
    public CQL_TABLE(Object TABLE){
        this.TABLE = TABLE;
    }
}
