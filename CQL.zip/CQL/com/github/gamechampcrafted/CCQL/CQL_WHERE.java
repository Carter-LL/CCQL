package com.github.gamechampcrafted.CCQL;

public class CQL_WHERE {
    public Object WHERE;
    public CQL_WHERE(Object WHERE){
        this.WHERE = WHERE;
    }
}
