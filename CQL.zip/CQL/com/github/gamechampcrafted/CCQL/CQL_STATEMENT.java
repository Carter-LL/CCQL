package com.github.gamechampcrafted.CCQL;

public enum CQL_STATEMENT {
    INSERT,
    UPDATE,
    SELECT,
}
